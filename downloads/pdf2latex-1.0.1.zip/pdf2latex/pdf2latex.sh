#!/bin/bash
# PDF2LATEX
# CC0 license
# Version: 1.0.1
export TERM=xterm
export ECHOBREAK=`tput setaf 4`
export ECHOHEAD=`tput setaf 3`
export ECHOTASK=`tput setaf 2`
export ECHOERROR=`tput setaf 1`
export ECHODEFAULT=`tput sgr0`
function echoBreak { 
	echo "${ECHOBREAK}================================${ECHODEFAULT}";
}
function echoTask {	
	echo "${ECHOBREAK}== ${ECHOTASK}$@${ECHODEFAULT}";
}
function echoHead {	
	echo "${ECHOBREAK}== ${ECHOHEAD}$@${ECHODEFAULT}";
}
function echoError { 
	echo "${ECHOERROR}!! $@${ECHODEFAULT}";
}

# exit script on error
set -e
# forbid loops to run if no matching file found
shopt -s nullglob

export DIRSINGLEPDF="tmp/pdf"
export DIRCROPPDF="pdf"

# pdfCrop <inputfilename> <outputfilename>
# uses ghostscript and pdf's boundingbox to cut white margin, but 5pt
function pdfCrop {
	export INFILE=$1
	export OUTFILE=$2	

	export INFOPS=$(pdfinfo $INFILE | grep "Page size:")
	
	export PAGEWIDTH=$(echo $INFOPS | cut -f4 -d\ )
	export PAGEHEIGHT=$(echo $INFOPS | cut -f6 -d\ )
	
	export INFOBB=$(gs -dSAFER -dNOPAUSE -dBATCH -sDEVICE=bbox "$INFILE" 2>&1 1>/dev/null)

	export margin=5
	
	export l=$(($(echo $INFOBB | cut -f2 -d\ )-margin))
	export b=$(($(echo $INFOBB | cut -f3 -d\ )-margin))
	export r=$(($(echo $INFOBB | cut -f4 -d\ )+margin))
	export t=$(($(echo $INFOBB | cut -f5 -d\ )+margin))
	
	export w=$((r-l))
	export h=$((t-b))
	
	export rmargin=$((PAGEWIDTH-r))
	export tmargin=$((PAGEHEIGHT-t))
	
	echoBreak
	echoTask "$INFILE: ${w}x${h} from ($l,$t) to ($r,$b) with margin of $margin"
	gs -o $OUTFILE  -sDEVICE=pdfwrite        -c "[/CropBox [$l $b $r $t]"  -c " /PAGES pdfmark"             -f $INFILE
	echoBreak
}


# creates a filename from label file or with fallback
function pdfPageFilename {
	SOURCEFILE=$1
	PAGENUM=$2
	DIR=$(dirname "${SOURCEFILE}")
	
	
	LABELSFILE="$1.labels.txt"
	
	if [ -e "$LABELSFILE" ]; then
		PROPOSEDFILENAME=$(sed "${PAGENUM}q;d" $LABELSFILE)
		
		if [ -n "$PROPOSEDFILENAME" ]; then
		echo "$DIRSINGLEPDF/$PROPOSEDFILENAME.pdf"
		else
	echo "$DIRSINGLEPDF/${SOURCEFILE%.*}-${PAGENUM}.pdf"
fi
else
	echo "$DIRSINGLEPDF/${SOURCEFILE%.*}-${PAGENUM}.pdf"
fi
}

for f in *.pdf; do
    echoBreak
    echoBreak
    echoTask "Processing File $f"
    PDFFILENAME=$f
    echoBreak
    echoBreak
	echoTask "qpdf PDF split pages to separate files"
	PDFPAGES=$(qpdf --show-npages $PDFFILENAME)
	echoTask "found $PDFPAGES pages"
	mkdir -p $DIRSINGLEPDF
	for i in $(seq 1 $PDFPAGES); do 
		PAGEFILENAME=$(pdfPageFilename $PDFFILENAME $i)
		if [[ $PAGEFILENAME -nt $PDFFILENAME ]]; then
			echoTask "skipping splitting (found page pdf is newer as sourcepdf)"
			break;
		else
		echoTask "splitting: $PDFFILENAME page $i to $PAGEFILENAME"
		qpdf --empty --pages "$PDFFILENAME" $i -- "$PAGEFILENAME"
		fi
	done
	echoBreak
	
	
	echoTask "ghostscript: cropping PDFs"
	mkdir -p pdf
	PATTERN=$DIRSINGLEPDF/*.pdf
	for f in $PATTERN
	do
		export FOUNDFILENAME=${f##*/}
	    export NEXTPDF="$DIRCROPPDF/${FOUNDFILENAME%.*}.pdf"
	    if [[ $NEXTPDF -nt $f ]]; then
			echoTask "skipping $NEXTPDF (cropped pdf newer as pdf)"
		else
			echoTask "pdfcrop $f $NEXTPDF"
	    	pdfCrop "$f" "$NEXTPDF"
		fi
	done
	echoBreak
	
	
	
	
#	echoTask "pdf2svg: convert to svg (just in case)"
#	mkdir -p svg
#	for f in pdf/*.pdf
#	do
#		export FOUNDFILENAME=${f##*/}
#	    export NEXTSVG="svg/${FOUNDFILENAME%.*}.svg"
#	    if [[ $NEXTSVG -nt $f ]]; then
#			echoTask "skipping ${NEXTSVG} (svg newer as pdf)"
#		else
#			echoTask "pdf2svg ${f} ${NEXTSVG}"	
#			pdf2svg $f $NEXTSVG
#	    fi
#	done
    echoBreak
    echoBreak
done
